/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Registerinfor;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.RegisterinforFacade;

/**
 *
 * @author 天王李靖小锟锟
 *
 *
 *
 * loginDo 用于登录验证
 */
public class loginDo extends HttpServlet {

    @EJB
    private RegisterinforFacade registerinforFacade;//注入EJB，登录注册会话组件

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
        //        设置编码
            request.setCharacterEncoding("UTF-8");
            response.setContentType("text/html;charset=UTF-8");
            //获取账号与密码
            String account = request.getParameter("acc");
            String password = request.getParameter("pass");
        //     获取全部信息
            List<Registerinfor> tempList = this.registerinforFacade.findAll();
        //        验证数据
            for (int i = 0; i < tempList.size(); i++) {
                Registerinfor get = tempList.get(i);
                if (account.equals(get.getUserAccount()) && password.equals(get.getUserPassword())) {
                    if ("M".equals(get.getUserNum().substring(0, 1))) {
                        response.sendRedirect("./adminMain?wnum=" + get.getUserNum());
                        return;
                    } else {
                        response.sendRedirect("./workerMain?wnum=" + get.getUserNum());
                        return;
                    }
                } else {
                    out.println("<script>alert('Login Fail!');window.location.href='./index.html'</script>");
                }
            }
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet loginDo</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet loginDo at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
