/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Dutyinfor;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.DutyinforFacade;

/**
 *
 * @author 天王李靖小锟锟
 */
public class adEditDuty extends HttpServlet {

    @EJB
    private DutyinforFacade dutyinforFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
           String wnum = request.getParameter("wnum");
            String date = request.getParameter("date");
            Dutyinfor newDutyinfor = new Dutyinfor();
            
            List<Dutyinfor> tempDutyinfors = this.dutyinforFacade.findAll();
            
            for (int i = 0; i < tempDutyinfors.size(); i++) {
                Dutyinfor get = tempDutyinfors.get(i);
                if (get.getUserNum().equals(wnum)&&get.getDate().equals(date)) {
                    newDutyinfor = get;
                }
                
            }
            this.dutyinforFacade.remove(newDutyinfor);
             out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet adminMain</title>");
            out.println("<meta charset=\"utf-8\">\n"
                    + "\n"
                    + "		<!-- 新 Bootstrap5 核心 CSS 文件 -->\n"
                    + "		<link rel=\"stylesheet\" href=\"https://cdn.staticfile.org/twitter-bootstrap/5.1.1/css/bootstrap.min.css\">\n"
                    + "		<link rel=\"icon\" type=\"image/x-icon\" href=\"assets/favicon.ico\" />\n"
                    + "		<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css\">\n"
                    + "\n"
                    + "		<!--jquery.js-->\n"
                    + "		<!--<script src=\"http://libs.baidu.com/jquery/2.0.0/jquery.min.js\"></script>-->\n"
                    + "		<!--<link rel=\"stylesheet\" href=\"https://cdn.staticfile.org/twitter-bootstrap/5.1.1/css/bootstrap.min.css\">-->\n"
                    + "		<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css\">\n"
                    + "		<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">\n"
                    + "		<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>\n"
                    + "		<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha3/dist/js/bootstrap.bundle.min.js\"></script>\n"
                    + "		<script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js\"></script>\n"
                    + "		<!--popper.min.js 用于弹窗、提示、下拉菜单-->\n"
                    + "		<script src=\"https://cdn.staticfile.org/popper.js/2.9.3/umd/popper.min.js\"></script>\n"
                    + "		<!--最新的 Bootstrap5 核心 JavaScript 文件-->\n"
                    + "		<script src=\"https://cdn.staticfile.org/twitter-bootstrap/5.1.1/js/bootstrap.min.js\"></script>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class=\"d-flex\" id=\"wrapper\">\n"
                    + "			<!-- Sidebar-->\n"
                    + "			<div class=\"border-end bg-white \" id=\"sidebar-wrapper \" style=\"width: 15%;\">\n"
                    + "				<!--<div class=\"sidebar-heading border-bottom bg-light\">Start Bootstrap</div>-->\n"
                    + "				<h1 style=\"height: 58px;\"><span class=\"badge bg-success\">HRM</span>系统</h1>\n"
                    + "				<div class=\"list-group list-group-flush\" style=\"height:650px; background-color: rgb(254,254,254)\">\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3 \" href=\"./adminMain\"><i class=\"bi-house\"></i>&nbsp;&nbsp;首页</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adWorView?page=1\"><i class=\"bi-book\"></i>&nbsp;&nbsp;员工信息管理</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adUnitView?page=1\"><i class=\"bi-bank\"></i>&nbsp;&nbsp;部门管理</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adSalView?page=1\"><i class=\"bi-wallet\"></i>&nbsp;&nbsp;薪资管理</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adLeaveView?page=1\"><i class=\"bi-journal\"></i>&nbsp;&nbsp;请假信息管理</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adDutyView?page=1\"><i class=\"bi-briefcase\"></i>&nbsp;&nbsp;出勤管理</a>\n"

                    + "				</div>\n"
                    + "			</div>");
            out.println("<!-- Page content wrapper-->\n"
                    + "			<div id=\"page-content-wrapper\" style=\"width: 85%;background: #c31432;  /* fallback for old browsers */\n"
                    + "                 background: -webkit-linear-gradient(to right, #240b36, #c31432);  /* Chrome 10-25, Safari 5.1-6 */\n"
                    + "                 background: linear-gradient(to right, #240b36, #c31432); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */\n"
                    + "                 \">");
            out.println("<!-- Top navigation-->\n"
                    + "				<nav class=\"navbar navbar-expand-lg navbar-light bg-light border-bottom\">\n"
                    + "					<div class=\"container-fluid\">\n"
                    + "						<span class=\"badge rounded-pill bg-dark\">您好，管理员</span>\n"
                    + "						<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\n"
                    + "							<ul class=\"navbar-nav ms-auto mt-2 mt-lg-0\">\n"
                    + "								<li class=\"nav-item active\"><a class=\"nav-link\" href=\"#!\">首页</a></li>\n"
                    + "								<li class=\"nav-item\"><a class=\"nav-link\" href=\"./index.html\">退出&nbsp;<i class=\"bi bi-box-arrow-right\"></i></a></li>\n"
                    + "							</ul>\n"
                    + "						</div>\n"
                    + "					</div>\n"
                    + "				</nav>");
            out.println("<!-- Page content-->\n"
                    + "	<div class=\"container-fluid\" style=\"margin-top: 50px;\">");
//主体部分
out.println("<div class=\"card\">\n" +
"						<!--功能栏-->\n" +
"						<!--表格主题-->\n" +
"						<div class=\"card-body\">\n" +
"							<h4 class=\"card-title\">编辑出勤信息</h4>\n" +
"							<form class=\"row g-3\" action='./adEditDutyDo'>\n" +
"\n" +
"								<div class=\"col-6\">\n" +
"									<label class=\"form-label\">工号</label>\n" +
"									<input name=\"wnum\" type=\"text\" class=\"form-control\" value='"+wnum
        + "' placeholder=\"\">\n" +
"								</div>\n" +
"								<div class=\"col-6\">\n" +
"									<label class=\"form-label\">天数</label>\n" +
"									<input name=\"day\" type=\"text\" class=\"form-control\" id=\"inputAddress2\" value='"+newDutyinfor.getDays()
                + "' placeholder=\"\">\n" +
"								</div>\n" +
"\n" +
"					\n" +
"						<div class=\"col-md-6\">\n" +
"							<label for=\"inputState\" class=\"form-label\">原因</label>\n" +
"							<textarea rows=\"5\" class=\"form-control\" name=\"reason\">\n" +
"								\n" +newDutyinfor.getReason()+
"							</textarea>\n" +
"							\n" +
"						</div>\n" +
"						<div class=\"col-md-6\">\n" +
"							<label for=\"inputState\" class=\"form-label\">时间</label>\n" +
"							<!-- 时间组件 -->\n" +
"							<div class=\"input-group date\" id=\"datepicker\">\n" +
"								<input type=\"text\" class=\"form-control\" value='"+date
        + "' name=\"date\">\n" +
"								<span class=\"input-group-append\">\n" +
"									<span class=\"input-group-text bg-white d-block\">\n" +
"										<i class=\"fa fa-calendar\"></i>\n" +
"									</span>\n" +
"								</span>\n" +
"							</div>\n" +
"						</div>\n" +
"\n" +
"						<div class=\"col-12\">\n" +
"							<button type=\"submit\" class=\"btn btn-primary\">提交</button>\n" +
"						</div>\n" +
"						</form>\n" +
"					</div>\n" +
"				</div>");
            out.println("</div>\n"
                    + "			</div></div>");
            
            out.println("<script type=\"text/javascript\">\n" +
"			$(function() {\n" +
"				$('#datepicker').datepicker();\n" +
"			});\n" +
"		</script>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
