/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.RegisterinforFacade;
import entities.*;
import model.WorkerinforFacade;

/**
 *
 * @author 天王李靖小锟锟
 */
public class workerMain extends HttpServlet {

    @EJB
    private WorkerinforFacade workerinforFacade;

    @EJB
    private RegisterinforFacade registerinforFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String wnum = request.getParameter("wnum");
            String name  = this.workerinforFacade.find(wnum).getName();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet workerMain</title>");
            out.println(" <meta charset=\"utf-8\">\n"
                    + "\n"
                    + "        <!-- 新 Bootstrap5 核心 CSS 文件 -->\n"
                    + "        <link rel=\"stylesheet\" href=\"https://cdn.staticfile.org/twitter-bootstrap/5.1.1/css/bootstrap.min.css\">\n"
                    + "        <link rel=\"icon\" type=\"image/x-icon\" href=\"assets/favicon.ico\" />\n"
                    + "        <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css\">\n"
                    + "        <!--popper.min.js 用于弹窗、提示、下拉菜单--> \n"
                    + "        <script src=\"https://cdn.staticfile.org/popper.js/2.9.3/umd/popper.min.js\"></script>\n"
                    + "        <!--最新的 Bootstrap5 核心 JavaScript 文件--> \n"
                    + "        <script src=\"https://cdn.staticfile.org/twitter-bootstrap/5.1.1/js/bootstrap.min.js\"></script>\n"
                    + "        <!--jquery.js-->\n"
                    + "        <script src=\"http://libs.baidu.com/jquery/2.0.0/jquery.min.js\"></script>");
            out.println("</head>");
            out.println("<body>");
            out.println("  <div class=\"d-flex\" id=\"wrapper\">\n"
                    + "            <!-- Sidebar-->\n"
                    + "            <div class=\"border-end bg-white\" id=\"sidebar-wrapper\" style=\"width: 15%;\">\n"
                    + "                <!--<div class=\"sidebar-heading border-bottom bg-light\">Start Bootstrap</div>-->\n"
                    + "                <h1  style=\"height: 58px;\"><span class=\"badge bg-primary\">HRM</span>系统</h1>\n"
                    + "                <div class=\"list-group list-group-flush\" style=\"height: 650px;\">\n"
                    + "                    <a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./workerMain?wnum="+wnum
                    + "\"><i class=\"bi bi-house\"></i>&nbsp;&nbsp;&nbsp;&nbsp;首页</a>\n"
                    + "                    <a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./editPassSer?wnum="
                    + wnum+
                    "\"><i class=\"bi bi-eraser\"></i>&nbsp;&nbsp;&nbsp;&nbsp;修改密码</a>\n"
                    + "                    <a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./leaveApply?wnum="+wnum
                            + "\"><i class=\"bi bi-flower1\"></i>&nbsp;&nbsp;&nbsp;&nbsp;请假申请</a>\n"
                    + "                    <a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./workerInforView?wnum="+wnum
                                    + "\"><i class=\"bi bi-info\"></i>&nbsp;&nbsp;&nbsp;&nbsp;信息查看</a>\n"
                    + "                </div>\n"
                    + "            </div>\n"
                    + "            <!-- Page content wrapper-->\n"
                    + "            <div id=\"page-content-wrapper\" style=\"width: 85%;\">\n"
                    + "                <!-- Top navigation-->\n"
                    + "                <nav class=\"navbar navbar-expand-lg navbar-light bg-light border-bottom\">\n"
                    + "                    <div class=\"container-fluid\">\n"
                    + "                        <span class=\"badge rounded-pill bg-dark\">您好，员工</span>\n"
                    + "                        <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\n"
                    + "                            <ul class=\"navbar-nav ms-auto mt-2 mt-lg-0\">\n"
                    + "                                <li class=\"nav-item active\"><a class=\"nav-link\" href=\"#!\">首页</a></li>\n"
                    + "                                <li class=\"nav-item\"><a class=\"nav-link\" href=\"./index.html\">退出</a></li>\n"
                    + "                            </ul>\n"
                    + "                        </div>\n"
                    + "                    </div>\n"
                    + "                </nav>\n"
            );

            out.println("          <!-- Page content-->\n"
                    + "                <div class=\"container-fluid\">\n");
//            页面主体信息
out.println("<div class=\"card\" style=\"height: 800px;\">\n" +
"						\n" +
"					<header class=\"py-5 bg-image-full\" style=\"background-image: url('https://images.unsplash.com/photo-1589700329490-73e2a07a9c51?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80')\">\n" +
"					    <div class=\"text-center my-5\">\n" +
"					        <img class=\"img-fluid rounded-circle mb-4\" src=\"https://dummyimage.com/150x150/8a288a/dcdded&text="+name.substring(1,2)
        + "\" alt=\"...\" />\n" +
"					        <h1 class=\"text-white fs-3 fw-bolder\">欢迎你，员工</h1>\n" +
"					        <p class=\"text-white-50 mb-0\">"+name
                + "</p>\n" +
"					    </div>\n" +
"					</header>\n" +
"					<!-- Content section-->\n" +
"					<section class=\"py-5\">\n" +
"					    <div class=\"container my-5\">\n" +
"					        <div class=\"row justify-content-center\">\n" +
"					            <div class=\"col-lg-6\">\n" +
"					                <h2>欢迎来到人力资源管理系统</h2>\n" +
"					                <p class=\"lead\">在这里，你可以对员工信息，部门信息，薪资信息，请假信息，出勤信息进行管理</p>\n" +
"					     \n" +
"					            </div>\n" +
"					        </div>\n" +
"					    </div>\n" +
"					</section>\n" +
"					\n" +
"				</div>");

            out.println("        </div>\n"
                    + "            </div>\n"
                    + "        </div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
