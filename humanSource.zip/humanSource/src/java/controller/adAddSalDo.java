/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Salaryinfor;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.SalaryinforFacade;


/**
 *
 * @author 天王李靖小锟锟
 */
public class adAddSalDo extends HttpServlet {

    @EJB
    private SalaryinforFacade salaryinforFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            
            //获取参数
            String wnum = request.getParameter("wnum");
            String sal = request.getParameter("sal");
            float fsal = Float.parseFloat(sal);
            String qua = request.getParameter("qua");
            
            List<Salaryinfor> tempSalaryinfors = this.salaryinforFacade.findAll();
            
            //输入验证
            
            for (int i = 0; i < tempSalaryinfors.size(); i++) {
                Salaryinfor get = tempSalaryinfors.get(i);
                if (get.getUserNum().equals(wnum)&&get.getQuarter().equals(qua)) {
                    out.println("<script>alert('添加信息重复!');window.location.href='./adAddSal'</script>");
                }
            }
            
            Salaryinfor newSalaryinfor = new  Salaryinfor(wnum,fsal , qua);
            this.salaryinforFacade.create(newSalaryinfor);
            response.sendRedirect("./adSalView?page=1");
            
            
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            
            out.println("<head>");
            out.println("<title>Servlet adAddSalDo</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet adAddSalDo at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
