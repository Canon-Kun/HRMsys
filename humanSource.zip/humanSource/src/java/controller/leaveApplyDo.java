/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.LeaveinforFacade;
import entities.*;
import java.util.List;

/**
 *
 * @author 天王李靖小锟锟
 */
public class leaveApplyDo extends HttpServlet {

    @EJB
    private LeaveinforFacade leaveinforFacade;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
      
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */ 
            String  wnum =  request.getParameter("wnum");
        String startTime  = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        String reason = request.getParameter("reason");
        String status = request.getParameter("status");
        int count = 0;
        List<Leaveinfor> tempList = this.leaveinforFacade.findAll();
            for (int i = 0; i < tempList.size(); i++) {
                Leaveinfor get = tempList.get(i);
                if (get.getUserNum().equals(wnum)) {
                    count++;
                }
                if (get.getUserNum().equals(wnum)&&get.getStartTime().equals(startTime)) {
                    out.println("<script>alert('请勿重复提交！');window.location.href='./workerMain?wnum="+wnum
                          + "'</script>");
                    return;
                }
            }
            if (count>2) {
                out.println("<script>alert('请假次数过多！');window.location.href='./workerMain?wnum="+wnum
                          + "'</script>");
                    return;
            }
        
        Leaveinfor newLeaveinfor = new Leaveinfor(wnum, startTime, endTime, reason);
        newLeaveinfor.setStatus(status);
        this.leaveinforFacade.create(newLeaveinfor);
         out.println("<script>alert('提交成功!');window.location.href='./workerMain?wnum="+wnum
                          + "'</script>");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet leaveApplyDo</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet leaveApplyDo at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
