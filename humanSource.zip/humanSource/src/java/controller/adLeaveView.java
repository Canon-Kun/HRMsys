/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.LeaveinforFacade;
import entities.*;
import java.util.List;
import model.WorkerinforFacade;

/**
 *
 * @author 天王李靖小锟锟
 */
public class adLeaveView extends HttpServlet {

    @EJB
    private WorkerinforFacade workerinforFacade;

    @EJB
    private LeaveinforFacade leaveinforFacade;

    
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
             out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet adminMain</title>");
            out.println("<meta charset=\"utf-8\">\n"
                    + "\n"
                    + "		<!-- 新 Bootstrap5 核心 CSS 文件 -->\n"
                    + "		<link rel=\"stylesheet\" href=\"https://cdn.staticfile.org/twitter-bootstrap/5.1.1/css/bootstrap.min.css\">\n"
                    + "		<link rel=\"icon\" type=\"image/x-icon\" href=\"assets/favicon.ico\" />\n"
                    + "		<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css\">\n"
                    + "\n"
                    + "		<!--jquery.js-->\n"
                    + "		<!--<script src=\"http://libs.baidu.com/jquery/2.0.0/jquery.min.js\"></script>-->\n"
                    + "		<!--<link rel=\"stylesheet\" href=\"https://cdn.staticfile.org/twitter-bootstrap/5.1.1/css/bootstrap.min.css\">-->\n"
                    + "		<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css\">\n"
                    + "		<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">\n"
                    + "		<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>\n"
                    + "		<script src=\"https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha3/dist/js/bootstrap.bundle.min.js\"></script>\n"
                    + "		<script src=\"https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js\"></script>\n"
                    + "		<!--popper.min.js 用于弹窗、提示、下拉菜单-->\n"
                    + "		<script src=\"https://cdn.staticfile.org/popper.js/2.9.3/umd/popper.min.js\"></script>\n"
                    + "		<!--最新的 Bootstrap5 核心 JavaScript 文件-->\n"
                    + "		<script src=\"https://cdn.staticfile.org/twitter-bootstrap/5.1.1/js/bootstrap.min.js\"></script>");
            out.println("</head>");
            out.println("<body>");
            String wnum = request.getParameter("wnum");
            
            //------------------------------实现分页-------------------------------

       int page =   Integer.parseInt( request.getParameter("page"));
       String outLeave = "";
       List<Leaveinfor> templeLeaveinfors = this.leaveinforFacade.findAll();
       
            if (page==1) {
                for (int i = 0; i < 4; i++) {
                    Leaveinfor get = templeLeaveinfors.get(i);
                    outLeave +="<tr>"+"<th>"+get.getUserNum()+"</th>"+"<th>"+this.workerinforFacade.find(get.getUserNum()).getName()+"</th>"+"<th>"+get.getStartTime()+"</th>"+"<th>"+get.getEndTime()+"</th>"+
                        "<th>"+get.getReason()+"</th>"+"<th>"+get.getStatus()+"</th>"+ "<th>" + "<a  class=\"btn btn-danger\" href=' ./adLeaveNO?wnum=" + get.getUserNum()+"&startTime="+get.getStartTime()
                        + " '  onClick=\"return confirm('确定驳回?');\"/ a>" + "驳回" + "</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                        + "<a onClick=\"return confirm('确定通过?');\"  class=\"btn btn-primary \" href=' ./adLeaveYes?wnum=" + get.getUserNum()+"&startTime="+get.getStartTime() + " ' / a>" + "通过" + "</a>"
                        + "</th>"+"<tr>";
                    
                }
            }else if(page==2){
                for (int i = 4; i < 8; i++) {
                     Leaveinfor get = templeLeaveinfors.get(i);
                    outLeave +="<tr>"+"<th>"+get.getUserNum()+"</th>"+"<th>"+this.workerinforFacade.find(get.getUserNum()).getName()+"</th>"+"<th>"+get.getStartTime()+"</th>"+"<th>"+get.getEndTime()+"</th>"+
                        "<th>"+get.getReason()+"</th>"+"<th>"+get.getStatus()+"</th>"+ "<th>" + "<a  class=\"btn btn-danger\" href=' ./adLeaveNO?wnum=" + get.getUserNum()+"&startTime="+get.getStartTime()
                        + " '  onClick=\"return confirm('确定驳回?');\"/ a>" + "驳回" + "</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                        + "<a onClick=\"return confirm('确定通过?');\"  class=\"btn btn-primary \" href=' ./adLeaveYes?wnum="  + get.getUserNum()+"&startTime="+get.getStartTime() + " ' / a>" + "通过" + "</a>"
                        + "</th>"+"<tr>";
                }
            
            }else{
                
                for (int i = 8; i < templeLeaveinfors.size(); i++) {
                      Leaveinfor get = templeLeaveinfors.get(i);
                    outLeave +="<tr>"+"<th>"+get.getUserNum()+"</th>"+"<th>"+this.workerinforFacade.find(get.getUserNum()).getName()+"</th>"+"<th>"+get.getStartTime()+"</th>"+"<th>"+get.getEndTime()+"</th>"+
                        "<th>"+get.getReason()+"</th>"+"<th>"+get.getStatus()+"</th>"+ "<th>" + "<a  class=\"btn btn-danger\" href=' ./adLeaveNO?wnum="  + get.getUserNum()+"&startTime="+get.getStartTime()
                        + " '  onClick=\"return confirm('确定驳回?');\"/ a>" + "驳回" + "</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
                        + "<a onClick=\"return confirm('确定通过?');\"  class=\"btn btn-primary \" href=' ./adLeaveYes?wnum="  + get.getUserNum()+"&startTime="+get.getStartTime() + " ' / a>" + "通过" + "</a>"
                        + "</th>"+"<tr>";
                }
            
            }
        
            
            
            out.println("<div class=\"d-flex\" id=\"wrapper\">\n"
                    + "			<!-- Sidebar-->\n"
                    + "			<div class=\"border-end bg-white \" id=\"sidebar-wrapper \" style=\"width: 15%;\">\n"
                    + "				<!--<div class=\"sidebar-heading border-bottom bg-light\">Start Bootstrap</div>-->\n"
                    + "				<h1 style=\"height: 58px;\"><span class=\"badge bg-success\">HRM</span>系统</h1>\n"
                    + "				<div class=\"list-group list-group-flush\" style=\"height:650px; background-color: rgb(254,254,254)\">\n"
                     + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3 \" href=\"./adminMain?wnum="+wnum
                    + "\"><i class=\"bi-house\"></i>&nbsp;&nbsp;首页</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adWorView?page=1&wnum="+wnum
                            + "\"><i class=\"bi-book\"></i>&nbsp;&nbsp;员工信息管理</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adUnitView?page=1&wnum="+wnum
                                    + "\"><i class=\"bi-bank\"></i>&nbsp;&nbsp;部门管理</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adSalView?page=1&wnum="+wnum
                                            + "\"><i class=\"bi-wallet\"></i>&nbsp;&nbsp;薪资管理</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adLeaveView?page=1&wnum="+wnum
                                                    + "\"><i class=\"bi-journal\"></i>&nbsp;&nbsp;请假信息管理</a>\n"
                    + "					<a class=\"list-group-item list-group-item-action list-group-item-light p-3\" href=\"./adDutyView?page=1&wnum="+wnum
                                                            + "\"><i class=\"bi-briefcase\"></i>&nbsp;&nbsp;出勤管理</a>\n"
                
                    + "				</div>\n"
                    + "			</div>");
            out.println("<!-- Page content wrapper-->\n"
                    + "			<div id=\"page-content-wrapper\" style=\"width: 85%;background: #c31432;  /* fallback for old browsers */\n"
                    + "                 background: -webkit-linear-gradient(to right, #240b36, #c31432);  /* Chrome 10-25, Safari 5.1-6 */\n"
                    + "                 background: linear-gradient(to right, #240b36, #c31432); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */\n"
                    + "                 \">");
            out.println("<!-- Top navigation-->\n"
                    + "				<nav class=\"navbar navbar-expand-lg navbar-light bg-light border-bottom\">\n"
                    + "					<div class=\"container-fluid\">\n"
                    + "						<span class=\"badge rounded-pill bg-dark\">您好，管理员</span>\n"
                    + "						<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">\n"
                    + "							<ul class=\"navbar-nav ms-auto mt-2 mt-lg-0\">\n"
                    + "								<li class=\"nav-item active\"><a class=\"nav-link\" href=\"#!\">首页</a></li>\n"
                    + "								<li class=\"nav-item\"><a class=\"nav-link\" href=\"./index.html\">退出&nbsp;<i class=\"bi bi-box-arrow-right\"></i></a></li>\n"
                    + "							</ul>\n"
                    + "						</div>\n"
                    + "					</div>\n"
                    + "				</nav>");
            out.println("<!-- Page content-->\n"
                    + "	<div class=\"container-fluid\" style=\"margin-top: 30px;\">");
            out.println(" <div class=\"card\">\n" +
"                        <!--功能栏-->\n" +
"                        <div class=\"card-body row\">\n" +
"                            <div class=\"col\">\n" +
"                                <form  class=\"row\" action=\"./adSearchLeave\">\n" +
"                                    <div class=\"col\">   <input type=\"text\" class=\"form-control\" id=\"inputPassword2\"  name='wnum'></div>\n" +
"                                    <div class=\"col\"> <button type=\"submit\" class=\"btn btn-primary mb-3\">查询</button></div>\n" +
"                                </form>  \n" +
"                            </div>\n" +

"                        </div>");
            out.println("<!--表格主题-->\n" +
"                        <div class=\"card-body\">\n" +
"                            <div class=\"table-responsive\">\n" +
"                                <table class=\"table  table-bordered table-hover \">\n" +
"                                    <thead>\n" +
"                                        <tr>\n" +
"                                            <th>工号</th>\n" +
                   "<th>姓名</th>"+
"                                            <th>开始时间</th>\n" +
"                                            <th>结束时间</th>\n" +
"                                            <th>请假原因</th>\n" +
                    "                                            <th>审核状态</th>\n" +
       "                                            <th width='15%'>操作</th>\n" +             
"                                        </tr>\n" +
"                                    </thead>");
            out.println(outLeave);
            out.println(" </table>\n" +"<ul class=\"pagination\">\n" +
"    <li class=\"page-item\"><a class=\"page-link\" href=\"./adLeaveView?page=1\">1</a></li>\n" +
"    <li class=\"page-item\"><a class=\"page-link\" href=\"./adLeaveView?page=2\">2</a></li>\n" +
"    <li class=\"page-item\"><a class=\"page-link\" href=\"./adLeaveView?page=3\">3</a></li>\n" +
"  </ul>"+
"                            </div>\n" +
"                        </div>\n" +
"                    </div>");
            out.println("</div>\n"
                    + "			</div></div>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
