/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 天王李靖小锟锟
 * 
 * 
 * 
 * 注册页面显示
 */
public class registerSer extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet registerSer</title>");
            out.println("	<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css\">\n"
                    + "	<link rel=\"icon\" type=\"image/png\" href=\"images/icons/favicon.ico\"/>\n"
                    + "\n"
                    + "	<link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/bootstrap/css/bootstrap.min.css\">\n"
                    + "\n"
                    + "	<link rel=\"stylesheet\" type=\"text/css\" href=\"fonts/font-awesome-4.7.0/css/font-awesome.min.css\">\n"
                    + "\n"
                    + "\n"
                    + "	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/util.css\">\n"
                    + "	<link rel=\"stylesheet\" type=\"text/css\" href=\"css/main.css\">");
            out.println("</head>");
            out.println("<div class=\"limiter\">\n" +
"		<div class=\"container-login100\">\n" +
"			<div class=\"wrap-login100\">\n" +
"			<!-- 	<div class=\"login100-pic js-tilt\" data-tilt>\n" +
"					<img src=\"images/img-01.png\" alt=\"IMG\">\n" +
"				</div> -->");
            out.println("<form class=\"login100-form validate-form\" style=\"margin: 0 auto;\" action='./registerDo'>");
            out.println("<span class=\"login100-form-title\">\n" +
"					注册界面\n" +
"					</span>");
            out.println("<div class=\"wrap-input100 validate-input\" data-validate = \"Valid email is required: ex@abc.xyz\">\n" +
"						<input class=\"input100\" type=\"text\" name=\"acc\" placeholder=\"账户\">\n" +
"						<span class=\"focus-input100\"></span>\n" +
"						<span class=\"symbol-input100\">\n" +
"							<i class=\"fa fa-envelope\" aria-hidden=\"true\"></i>\n" +
"						</span>\n" +
"					</div>");
            out.println("<div class=\"wrap-input100 validate-input\" data-validate = \"Password is required\">\n" +
"						<input class=\"input100\" type=\"password\" name=\"pass\" placeholder=\"密码\">\n" +
"						<span class=\"focus-input100\"></span>\n" +
"						<span class=\"symbol-input100\">\n" +
"							<i class=\"fa fa-lock\" aria-hidden=\"true\"></i>\n" +
"						</span>\n" +
"					</div>");
            out.println("			<div class=\"wrap-input100 validate-input\" data-validate = \"Password is required\">\n" +
"						<input class=\"input100\" type=\"text\" name=\"wnum\" placeholder=\"工号\">\n" +
"						<span class=\"focus-input100\"></span>\n" +
"						<span class=\"symbol-input100\">\n" +
"							<i class=\"bi bi-circle-square\"></i>\n" +
"						</span>\n" +
"					</div>");
            out.println("	<div class=\"container-login100-form-btn\">\n" +
"						<button class=\"login100-form-btn\">\n" +
"							确认\n" +
"						</button>\n" +
"					</div>");
            out.println("			<div class=\"text-center p-t-136\">\n" +
"						<a class=\"txt2\" href=\"index.html\">\n" +
"							返回\n" +
"							<i class=\"fa fa-long-arrow-right m-l-5\" aria-hidden=\"true\"></i>\n" +
"						</a>\n" +
"					</div>\n" +
"				</form>");
            out.println("		</div>\n" +
"		</div>\n" +
"	</div>");
            out.println("<body>");
//            out.println("<h1>Servlet registerSer at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
