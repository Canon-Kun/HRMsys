/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Registerinfor;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author 天王李靖小锟锟
 *
 *
 * 登录注册会话组件
 */
@Stateless
public class RegisterinforFacade extends AbstractFacade<Registerinfor> {

    @PersistenceContext(unitName = "humanSourcePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {

        return em;
    }

    public RegisterinforFacade() {
        super(Registerinfor.class);
    }
//查询账户名
    public List<Registerinfor> findByAcc(String acc) {
        List<Registerinfor> temp = new ArrayList<>();
       List<Registerinfor> allList=this.findAll();
        for (int i = 0; i < allList.size(); i++) {
            Registerinfor get = allList.get(i);
            if (get.getUserAccount().equals(acc)) {
                 temp.add(get);
            }
            
        }
        return temp;
    }
    public List<Registerinfor> findBynum(String wnum){
       Query query  =  em.createNamedQuery("Registerinfor.findByUserNum");
List<Registerinfor>  newRegisterinfor  = new  ArrayList<>();
    newRegisterinfor = query.setParameter("userNum", wnum).getResultList();
    return newRegisterinfor;
    
    
    
    }
}
