/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Organizationinfor;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author 天王李靖小锟锟
 */
@Stateless
public class OrganizationinforFacade extends AbstractFacade<Organizationinfor> {

    @PersistenceContext(unitName = "humanSourcePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public OrganizationinforFacade() {
        super(Organizationinfor.class);
    }
    
}
