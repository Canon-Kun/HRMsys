/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import entities.Workerinfor;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author 天王李靖小锟锟
 */
@Stateless
public class WorkerinforFacade extends AbstractFacade<Workerinfor> {
    
    
   private String nameString;
    @PersistenceContext(unitName = "humanSourcePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public WorkerinforFacade() {
        super(Workerinfor.class);
    }
    

    public String getNameString() {
        return nameString;
    }

    public void setNameString(String nameString) {
        this.nameString = nameString;
    }

  
    
    
}
