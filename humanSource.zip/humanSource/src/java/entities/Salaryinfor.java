/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 天王李靖小锟锟
 */
@Entity
@Table(name = "salaryinfor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Salaryinfor.findAll", query = "SELECT s FROM Salaryinfor s")
    , @NamedQuery(name = "Salaryinfor.findByUserNum", query = "SELECT s FROM Salaryinfor s WHERE s.userNum = :userNum")
    , @NamedQuery(name = "Salaryinfor.findBySalary", query = "SELECT s FROM Salaryinfor s WHERE s.salary = :salary")
    , @NamedQuery(name = "Salaryinfor.findByQuarter", query = "SELECT s FROM Salaryinfor s WHERE s.quarter = :quarter")})
public class Salaryinfor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "user_num")
    private String userNum;
    @Basic(optional = false)
    @NotNull
    @Column(name = "salary")
    private float salary;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "quarter")
    private String quarter;

    public Salaryinfor() {
    }

    public Salaryinfor(String userNum) {
        this.userNum = userNum;
    }

    public Salaryinfor(String userNum, float salary, String quarter) {
        this.userNum = userNum;
        this.salary = salary;
        this.quarter = quarter;
    }

    public String getUserNum() {
        return userNum;
    }

    public void setUserNum(String userNum) {
        this.userNum = userNum;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public String getQuarter() {
        return quarter;
    }

    public void setQuarter(String quarter) {
        this.quarter = quarter;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userNum != null ? userNum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Salaryinfor)) {
            return false;
        }
        Salaryinfor other = (Salaryinfor) object;
        if ((this.userNum == null && other.userNum != null) || (this.userNum != null && !this.userNum.equals(other.userNum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Salaryinfor[ userNum=" + userNum + " ]";
    }
    
}
