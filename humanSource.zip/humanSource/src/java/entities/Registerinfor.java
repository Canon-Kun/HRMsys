/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 天王李靖小锟锟
 */
@Entity
@Table(name = "registerinfor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Registerinfor.findAll", query = "SELECT r FROM Registerinfor r")
    , @NamedQuery(name = "Registerinfor.findByUserAccount", query = "SELECT r FROM Registerinfor r WHERE r.userAccount = :userAccount")
    , @NamedQuery(name = "Registerinfor.findByUserPassword", query = "SELECT r FROM Registerinfor r WHERE r.userPassword = :userPassword")
    , @NamedQuery(name = "Registerinfor.findByUserNum", query = "SELECT r FROM Registerinfor r WHERE r.userNum = :userNum")})
public class Registerinfor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "user_account")
    private String userAccount;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "user_password")
    private String userPassword;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "user_num")
    private String userNum;

    public Registerinfor() {
    }

    public Registerinfor(String userAccount) {
        this.userAccount = userAccount;
    }

    public Registerinfor(String userAccount, String userPassword, String userNum) {
        this.userAccount = userAccount;
        this.userPassword = userPassword;
        this.userNum = userNum;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getUserNum() {
        return userNum;
    }

    public void setUserNum(String userNum) {
        this.userNum = userNum;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userAccount != null ? userAccount.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Registerinfor)) {
            return false;
        }
        Registerinfor other = (Registerinfor) object;
        if ((this.userAccount == null && other.userAccount != null) || (this.userAccount != null && !this.userAccount.equals(other.userAccount))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Registerinfor[ userAccount=" + userAccount + " ]";
    }
    
}
