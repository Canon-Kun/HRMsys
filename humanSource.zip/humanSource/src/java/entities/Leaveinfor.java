/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 天王李靖小锟锟
 */
@Entity
@Table(name = "leaveinfor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Leaveinfor.findAll", query = "SELECT l FROM Leaveinfor l")
    , @NamedQuery(name = "Leaveinfor.findByUserNum", query = "SELECT l FROM Leaveinfor l WHERE l.userNum = :userNum")
    , @NamedQuery(name = "Leaveinfor.findByStartTime", query = "SELECT l FROM Leaveinfor l WHERE l.startTime = :startTime")
    , @NamedQuery(name = "Leaveinfor.findByEndTime", query = "SELECT l FROM Leaveinfor l WHERE l.endTime = :endTime")
    , @NamedQuery(name = "Leaveinfor.findByReason", query = "SELECT l FROM Leaveinfor l WHERE l.reason = :reason")
    , @NamedQuery(name = "Leaveinfor.findByStatus", query = "SELECT l FROM Leaveinfor l WHERE l.status = :status")})
public class Leaveinfor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "user_num")
    private String userNum;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "startTime")
    private String startTime;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "endTime")
    private String endTime;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1000)
    @Column(name = "reason")
    private String reason;
    @Size(max = 20)
    @Column(name = "status")
    private String status;

    public Leaveinfor() {
    }

    public Leaveinfor(String userNum) {
        this.userNum = userNum;
    }

    public Leaveinfor(String userNum, String startTime, String endTime, String reason) {
        this.userNum = userNum;
        this.startTime = startTime;
        this.endTime = endTime;
        this.reason = reason;
    }

    public String getUserNum() {
        return userNum;
    }

    public void setUserNum(String userNum) {
        this.userNum = userNum;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userNum != null ? userNum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Leaveinfor)) {
            return false;
        }
        Leaveinfor other = (Leaveinfor) object;
        if ((this.userNum == null && other.userNum != null) || (this.userNum != null && !this.userNum.equals(other.userNum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Leaveinfor[ userNum=" + userNum + " ]";
    }
    
}
