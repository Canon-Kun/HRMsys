/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 天王李靖小锟锟
 */
@Entity
@Table(name = "dutyinfor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Dutyinfor.findAll", query = "SELECT d FROM Dutyinfor d")
    , @NamedQuery(name = "Dutyinfor.findByUserNum", query = "SELECT d FROM Dutyinfor d WHERE d.userNum = :userNum")
    , @NamedQuery(name = "Dutyinfor.findByDays", query = "SELECT d FROM Dutyinfor d WHERE d.days = :days")
    , @NamedQuery(name = "Dutyinfor.findByReason", query = "SELECT d FROM Dutyinfor d WHERE d.reason = :reason")
    , @NamedQuery(name = "Dutyinfor.findByDate", query = "SELECT d FROM Dutyinfor d WHERE d.date = :date")})
public class Dutyinfor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "user_num")
    private String userNum;
    @Basic(optional = false)
    @NotNull
    @Column(name = "days")
    private int days;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1000)
    @Column(name = "reason")
    private String reason;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "date")
    private String date;

    public Dutyinfor() {
    }

    public Dutyinfor(String userNum) {
        this.userNum = userNum;
    }

    public Dutyinfor(String userNum, int days, String reason, String date) {
        this.userNum = userNum;
        this.days = days;
        this.reason = reason;
        this.date = date;
    }

    public String getUserNum() {
        return userNum;
    }

    public void setUserNum(String userNum) {
        this.userNum = userNum;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userNum != null ? userNum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Dutyinfor)) {
            return false;
        }
        Dutyinfor other = (Dutyinfor) object;
        if ((this.userNum == null && other.userNum != null) || (this.userNum != null && !this.userNum.equals(other.userNum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Dutyinfor[ userNum=" + userNum + " ]";
    }
    
}
