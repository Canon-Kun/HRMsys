/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 天王李靖小锟锟
 */
@Entity
@Table(name = "workerinfor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Workerinfor.findAll", query = "SELECT w FROM Workerinfor w")
    , @NamedQuery(name = "Workerinfor.findByUserNum", query = "SELECT w FROM Workerinfor w WHERE w.userNum = :userNum")
    , @NamedQuery(name = "Workerinfor.findByOrgId", query = "SELECT w FROM Workerinfor w WHERE w.orgId = :orgId")
    , @NamedQuery(name = "Workerinfor.findBySex", query = "SELECT w FROM Workerinfor w WHERE w.sex = :sex")
    , @NamedQuery(name = "Workerinfor.findByName", query = "SELECT w FROM Workerinfor w WHERE w.name = :name")
    , @NamedQuery(name = "Workerinfor.findByCountry", query = "SELECT w FROM Workerinfor w WHERE w.country = :country")
    , @NamedQuery(name = "Workerinfor.findByPeople", query = "SELECT w FROM Workerinfor w WHERE w.people = :people")
    , @NamedQuery(name = "Workerinfor.findByDate", query = "SELECT w FROM Workerinfor w WHERE w.date = :date")})
public class Workerinfor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "user_num")
    private String userNum;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "org_id")
    private String orgId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "sex")
    private String sex;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "country")
    private String country;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "people")
    private String people;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "date")
    private String date;

    public Workerinfor() {
    }

    public Workerinfor(String userNum) {
        this.userNum = userNum;
    }

    public Workerinfor(String userNum, String orgId, String sex, String name, String country, String people, String date) {
        this.userNum = userNum;
        this.orgId = orgId;
        this.sex = sex;
        this.name = name;
        this.country = country;
        this.people = people;
        this.date = date;
    }

    public String getUserNum() {
        return userNum;
    }

    public void setUserNum(String userNum) {
        this.userNum = userNum;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPeople() {
        return people;
    }

    public void setPeople(String people) {
        this.people = people;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (userNum != null ? userNum.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Workerinfor)) {
            return false;
        }
        Workerinfor other = (Workerinfor) object;
        if ((this.userNum == null && other.userNum != null) || (this.userNum != null && !this.userNum.equals(other.userNum))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Workerinfor[ userNum=" + userNum + " ]";
    }
    
}
