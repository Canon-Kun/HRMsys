/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author 天王李靖小锟锟
 */
@Entity
@Table(name = "organizationinfor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Organizationinfor.findAll", query = "SELECT o FROM Organizationinfor o")
    , @NamedQuery(name = "Organizationinfor.findById", query = "SELECT o FROM Organizationinfor o WHERE o.id = :id")
    , @NamedQuery(name = "Organizationinfor.findByName", query = "SELECT o FROM Organizationinfor o WHERE o.name = :name")
    , @NamedQuery(name = "Organizationinfor.findByDescription", query = "SELECT o FROM Organizationinfor o WHERE o.description = :description")
    , @NamedQuery(name = "Organizationinfor.findByPId", query = "SELECT o FROM Organizationinfor o WHERE o.pId = :pId")})
public class Organizationinfor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "id")
    private String id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "name")
    private String name;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1000)
    @Column(name = "description")
    private String description;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "p_id")
    private String pId;

    public Organizationinfor() {
    }

    public Organizationinfor(String id) {
        this.id = id;
    }

    public Organizationinfor(String id, String name, String description, String pId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.pId = pId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPId() {
        return pId;
    }

    public void setPId(String pId) {
        this.pId = pId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Organizationinfor)) {
            return false;
        }
        Organizationinfor other = (Organizationinfor) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Organizationinfor[ id=" + id + " ]";
    }
    
}
